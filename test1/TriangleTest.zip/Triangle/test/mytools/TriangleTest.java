/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mytools;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author yourname
 */
public class TriangleTest {

    public TriangleTest() {
    }

    /**
     * Test of getA method, of class Triangle.
     */
    @Test
    public void testGetA() {
        System.out.println("getA");
        Triangle instance = new Triangle(3, 4, 5);
        int expResult = 3;
        int result = instance.getA();
        assertEquals(expResult, result);
    }

//    /**
//     * Test of getB method, of class Triangle.
//     */
//    @Test
//    public void testGetB() {
//        System.out.println("getB");
//        Triangle instance = null;
//        int expResult = 0;
//        int result = instance.getB();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getC method, of class Triangle.
//     */
//    @Test
//    public void testGetC() {
//        System.out.println("getC");
//        Triangle instance = null;
//        int expResult = 0;
//        int result = instance.getC();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
    /**
     * Test of allPositive method, of class Triangle.
     */
    @Test
    public void testAllPositive() {
        System.out.println("allPositive");
        // case 1
        Triangle instance = new Triangle(-3, 4, 5);
        boolean expResult = false;
        boolean result = instance.allPositive();
        assertEquals(expResult, result);
        // case 2
        instance = new Triangle(3, 4, 5);
        expResult = true;
        result = instance.allPositive();
        assertEquals(expResult, result);
        // case 3
        instance = new Triangle(0, 4, 5);
        expResult = false;
        result = instance.allPositive();
        assertEquals(expResult, result);
    }
//

    /**
     * Test of isValid method, of class Triangle.
     */
    @Test
    public void testIsValid() {
        System.out.println("isValid");
        // case 1
        Triangle instance = new Triangle(3, 4, 5);;
        boolean expResult = true;
        boolean result = instance.isValid();
        assertEquals(expResult, result);
        // case 2
        instance = new Triangle(0, 4, 5);
        expResult = false;
        result = instance.isValid();
        assertEquals(expResult, result);
        // case 3
        instance = new Triangle(-1, 4, 5);
        expResult = false;
        result = instance.isValid();
        assertEquals(expResult, result);
        // case 4
        instance = new Triangle(1, 3, 5);
        expResult = false;
        result = instance.isValid();
        assertEquals(expResult, result);
    }
//    
}
