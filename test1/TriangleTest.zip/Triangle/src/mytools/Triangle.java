package mytools;

public class Triangle {

    private int a, b, c; // Three property members represent the length of three edges in a triangle, respectively

    public Triangle(int a, int b, int c) {
        // Constructor which initializes a, b and c
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public int getA() {// getter for a
        return a;
    }

    public int getB() {// getter for b
        return b;
    }

    public int getC() {// getter for c
        return c;
    }

    boolean allPositive() {
        // Examine if all three lengths in a, b and c have a positive value
        // The method returns true if every length is positive and false otherwise
        return a > 0 && b > 0 && c > 0;
    }

    public boolean isValid() {
        // Examine if a, b and c make a valid triangle        
        // The method returns true if a, b and c make a triangle and false otherwise. 
        return this.allPositive() && (a + b) > c && (b + c) > a && (c + a) > b;
    }
    
}
